public class IO {
    public static void println(Object o) {
        System.out.println(o);
    }
}
